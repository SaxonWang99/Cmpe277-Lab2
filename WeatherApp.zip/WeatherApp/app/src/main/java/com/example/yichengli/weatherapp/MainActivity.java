package com.example.yichengli.weatherapp;

import android.app.FragmentManager;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity  {
   // private static final int REQUEST_CITY_CODE = 100;
    private MainMenuFragment mainMenuFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fm = getFragmentManager();
        mainMenuFragment = (MainMenuFragment) fm.findFragmentById(R.id.container);

        if (mainMenuFragment == null) {
            mainMenuFragment = new MainMenuFragment();
            fm.beginTransaction().add(R.id.container, mainMenuFragment).commit();
        }
    }


}

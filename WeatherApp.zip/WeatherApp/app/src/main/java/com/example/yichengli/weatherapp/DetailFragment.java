package com.example.yichengli.weatherapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Inspiron on 2017/11/8.
 */

public class DetailFragment extends Fragment {

    public static DetailFragment newInstance(int index, ArrayList<String> mCities) {
        DetailFragment f = new DetailFragment();

        Bundle args = new Bundle();
        args.putString("city", mCities.get(index));
        f.setArguments(args);

        return f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup view = (ViewGroup) inflater.inflate(R.layout.fragment_detail, container, false );

        TextView text = (TextView) view.findViewById(R.id.city_page);
        text.setText(getArguments().getString("city", "xxx"));


        return view;

    }


}


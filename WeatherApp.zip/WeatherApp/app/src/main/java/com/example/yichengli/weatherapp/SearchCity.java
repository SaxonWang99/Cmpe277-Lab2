package com.example.yichengli.weatherapp;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SearchCity extends AppCompatActivity {
    EditText cityInput;
    Button btn;
    public static final String RESPONSE = "response";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_city);

       cityInput = (EditText) findViewById(R.id.city_input);
       btn = (Button) findViewById(R.id.btn1);
       btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent();
               String str = cityInput.getText().toString();
               intent.putExtra(RESPONSE ,str );
               Context context = getApplicationContext();
               Toast toast = Toast.makeText(context, str, Toast.LENGTH_SHORT);
               toast.show();
               setResult(RESULT_OK, intent);
               finish();
           }
       });
    }
    

}
